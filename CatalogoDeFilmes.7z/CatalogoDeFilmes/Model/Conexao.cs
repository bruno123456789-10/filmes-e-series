﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CatalogoDeFilmes.Model
{
    internal class Conexao
    {
        public static string Conectar()
        {


            return @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\bruno.dothome\source\repos\CatalogoDeFilmes\CatalogoDeFilmes\Model\Filmesbd.mdf;Integrated Security=True";
        }
    }
}
