﻿using CatalogoDeFilmes.Controller;
using CatalogoDeFilmes.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CatalogoDeFilmes.View
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void btFilme_Click(object sender, EventArgs e)
        {
            TelaCadastroFilme TelaFilme = new TelaCadastroFilme();
            TelaFilme.Show();
            this.Close();
        }

        private void btSerie_Click(object sender, EventArgs e)
        {
            TelaCadastroSerie TelaSerie = new TelaCadastroSerie();
            TelaSerie.Show();
            this.Close();
        }
    }
}
